from __future__ import annotations

import re
import sys
import shutil
import logging
import subprocess
import importlib.util

import click
from grpc import contextlib
from rich import print

logger = logging.getLogger(__name__)


DOCKER_CMD = "docker"  # or "podman" if available
CMD_VERIFY_NVIDIA_DOCKER = (
    "docker run --rm --gpus all nvidia/cuda:11.6.2-base-ubuntu20.04 nvidia-smi"
)

SUCCESS_SIGN = "[green]✓[/green]"
ERROR_SIGN = "[red]✕[/red]"
WARNING_SIGN = "[yellow]⚠[/yellow]"


def check_env() -> bool:
    """Check the environment and print the result"""
    flag = True
    print("Checking environment:")
    if sys.version_info >= (3, 6):
        print(f"{SUCCESS_SIGN} Python 3.6+ found")
    else:
        print(f"{ERROR_SIGN} Python 3.6+ not found")
        flag = False

    if shutil.which(DOCKER_CMD):
        print(f"{SUCCESS_SIGN} {DOCKER_CMD} found")
    else:
        print(f"{ERROR_SIGN} {DOCKER_CMD} not found")
        flag = False

    if importlib.util.find_spec("locust") is not None:
        print(f"{SUCCESS_SIGN} locust found")
    else:
        print(f"{ERROR_SIGN} locust not found")
        flag = False

    if not subprocess.check_call(
        CMD_VERIFY_NVIDIA_DOCKER,
        shell=True,
        stdout=subprocess.DEVNULL,
    ):
        print(f"{SUCCESS_SIGN} Nvidia Docker found")
    else:
        print(f"{WARNING_SIGN} Nvidia Docker not found, will use CPU only")

    return flag


def build_image(bento: str) -> str:
    output = subprocess.check_output(
        [sys.executable, "-m", "bentoml", "containerize", bento],
        stderr=subprocess.STDOUT,
    ).decode("utf-8")
    # example output: Successfully built Bento container for "iris_classifier:1.0.0" with tag(s) "iris_classifier:1.0.0"
    mat = re.search(
        r"Successfully built Bento container for \"(.*)\" with tag\(s\) \"(.*)\"",
        output,
    )
    if mat:
        _, bento_tag = mat.groups()
        return bento_tag
    return ""


def _start_http_server_in_docker(
    image_tag: str,
    remote_runners: dict[str, str],
    port: int,
    cpus: int = 2,
    gpus: int = 0,
) -> str:
    # example CMD: docker run -it --rm -p 3000:3000 iris_classifier:1.0.0 start-http-server --depends iris_clf=127.0.0.1:4000
    cmd = [
        DOCKER_CMD,
        "run",
        f"--cpus={cpus}",
        "-it",
        "--rm",
        "-p",
        f"{port}:3000",
        image_tag,
        "start-http-server",
    ]
    for name, addr in remote_runners.items():
        cmd.extend(["--depends", f"{name}={addr}"])
    if gpus:
        cmd.insert(1, f"--gpus={gpus}")
    output = subprocess.check_output(cmd).decode("utf-8")
    return output.strip()


@contextlib.contextmanager
def _start_bento_in_docker(
    bento_tag: str,
    image_tag: str,
    cpu_per_runner: int = 2,
    gpu_per_runner: int = 0,
):
    yield None


def add_doctor_command(cli: click.Group) -> None:
    @cli.command()
    @click.argument("bento", type=click.STRING)
    @click.option(
        "--locustfile",
        type=click.STRING,
    )
    def doctor(  # type: ignore (unused warning)
        bento: str,
        locustfile: str,
    ) -> None:
        if not check_env():
            return
        tag = build_image(bento)
        if not tag:
            return
        print(tag)
        import bentoml

        bento_info = bentoml.get(bento)
        runner_infos = bento_info.info.runners
